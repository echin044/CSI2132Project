# novigrad-project---part-1-g26
novigrad-project---part-1-g26 created by GitHub Classroom


Voici les informations sauvegardées dans notre base de données.


Compte administrateur:

-Username: "admin"
-Password: "123admin456"


Compte employés:

-Username: "EmployeA"
-Password: "12345"
-Succursale: "A"

-Username: "EmployeB"
-Password: "12345"
-Succursale: "B"

-Username: "EmployeC"
-Password: "12345"
-Succursale: "C"

-Username: "EmployeD"
-Password: "12345"
-Succursale: "D"

-Username: "EmployeE"
-Password: "12345"
-Succursale: "E"

-Username: "EmployeF"
-Password: "12345"
-Succursale: "F"

Compte clients:

-Username: "Eric"
-Password: "@Ottawa1234"

-Username: "Erik"
-Password: "OTTAWA"

-Username: "Idiris"
-Password: "123456"



#Voici les membres qui ont contribué au projet: Eric Tessier, Erik Chin et Idiris Cabdulle.
#Et les autres membres qui n'ont pas contribué: Benjamin Denis, Anas Bourfia
