package com.example.servicenovigrad;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)

@Suite.SuiteClasses({
        Test1.class,
        Test2.class,
        Test3.class,
        Test4.class,
        Test5.class,
        Test6.class,
        Test7.class,
        Test8.class,
        Test9.class,
        Test10.class,
        Test11.class,
        Test12.class
})

public class TestSuite {

}

