package com.example.servicenovigrad.data.Class;

public class Admin extends UserModel {
}
